#ifndef SHANNON_CORE_NET_PUBSUB_H_
#define SHANNON_CORE_NET_PUBSUB_H_

// -------------------------------------------------------------------------- //
// Since the PUBSUB sockets which bind are already handled by the
// `znd_bus_relay`, we only need to support a "connect" interface.
// -------------------------------------------------------------------------- //

#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include "net/protocol/pubsub.h"

#ifdef __cplusplus
extern "C" {
#endif

///
/// Opaque handle for a pubsub socket.
///
typedef void Shannon_PubSubSocket;

///
/// Create a new pubsub socket.  By default it is not connected as a publisher
/// or subscriber to any destination.  You must call
/// `Shannon_PubSubSocket_Connect` for this.
///
/// Returns 0x0 on memory failure.
///
Shannon_PubSubSocket*
Shannon_PubSubSocket_New(void);

///
/// Close the socket and free any used memory.
///
void
Shannon_PubSubSocket_Destroy(Shannon_PubSubSocket* socket);

///
/// Connect a pubsub socket.
///
/// If you populate `uri_pub`, you are connecting this socket as a subscriber
/// socket to the publisher at pub.  You can set to 0x0 if you do not want to
/// connect.
///
/// If you populate `uri_sub`, you are connecting this socket as a publisher
/// socket to the subscriber at sub.  You can set to 0x0 if you do not want to
/// connect.
///
/// You can do both or either.
///
/// Return 0 on success.
///
int
Shannon_PubSubSocket_Connect(
    Shannon_PubSubSocket* socket,
    const char* uri_pub,
    const char* uri_sub);

///
/// Listen to a pubsub socket
/// TODO::Only a temporary fix
int
Shannon_PubSubSocket_Listen(
    Shannon_PubSubSocket* socket,
    const char* uri_sub);

/// {
/// This assumes that the socket is connected as a subscriber.  It subscribes
/// to a `Shannon_Channel` to a `channel_level` depth.
///
/// There is more explanation in the documentation for that structure, but
/// in short...
///
/// Subscriptions are a `memcmp`.  While the channel name is always 8 bytes, we
/// may wish to subscribe to all messages prefixed by less than 8 bytes.
///
/// Use the `Shannon_ChannelLevel` macro to compute the proper offset.
///
int
Shannon_PubSubSocket_Subscribe(
    Shannon_PubSubSocket* socket,
    Shannon_Channel channel,
    unsigned channel_level);

// This subscribes to everything -
// useful for debugging errors related to subscribe channels
int
Shannon_PubSubSocket_SubscribeAll(Shannon_PubSubSocket* socket);


int
Shannon_PubSubSocket_UnSubscribe(
    Shannon_PubSubSocket* socket,
    Shannon_Channel channel,
    unsigned channel_level);
/// }

///
/// Receive a new message.  It returns 0 when successful.
///
/// When successful it will:
/// - allocate the necessary memory into `*data`
/// - populate `*data` with the memory.
/// - populate `*sender_identity` with the address of the sender.
/// - populate `*size` with the size poulated.
/// - populate the *channel with the correct channel information.
///
/// If any of these are null, they will be ignored (with exception to the *data)
/// field.
///
/// It is the responsibility of the caller to call `free` on the
/// returned memory.
///
/// If the broadcast message has no body, no memory will be allocated and the
/// size will be 0, but the channel will still be populated and it will return
/// 0 for success.
///
int
Shannon_PubSubSocket_Recv(
    Shannon_PubSubSocket* socket,
    uint64_t* sender_identity,
    Shannon_Channel* channel,
    void**  data,
    size_t* size);

///
/// Send a message on publisher socket (assumes it was opened as one).
///
/// Message is sent to `channel`.  If data is null, the broadcast message will
/// just be the channel.  Please populate size appropriately as `0`.
///
/// Otherwise `size` bytes will be copied from `data` to be published as the
/// message.
///
int
Shannon_PubSubSocket_Send(
    Shannon_PubSubSocket* socket,
    Shannon_Channel channel,
    const void*  data,
    size_t size);

///
/// Timeouts for sending/receiving on this socket.
///
int
Shannon_PubSubSocket_SetTimeout(
    Shannon_PubSubSocket* socket,
    int timeout_recv_ms,
    int timeout_send_ms);

#ifdef __cplusplus
} // extern
#endif



#endif // SHANNON_CORE_NET_PUBSUB_H_
