#ifndef SHANNON_CORE_NET_URI_H_
#define SHANNON_CORE_NET_URI_H_

/// TODO: This internally is a bit of a mess, since it's currently working I
///       won't  touch it.  But these methods should not be public like this.

#include <stdint.h>
#include <string.h>

#include "net/protocol/broadcast.h"

#ifdef __cplusplus
extern "C" {
#endif

/// {
/// These functions generate URI's that are appropriate for usage in the TCP or
/// IPC connection modes.
const char*
Shannon_DefaultIpcSubUri(void);

const char*
Shannon_DefaultIpcPubUri(void);

const char*
Shannon_DefaultIpcRepUri(void);

const char*
Shannon_UriIPC(
    char*       buffer,
    unsigned    buffer_length,
    const char* channel);

const char*
Shannon_TcpUriIPV4(
    char*    buffer,
    unsigned buffer_length,
    uint32_t ip,
    uint16_t port);

const char*
Shannon_TcpUriIPV6(
    char*    buffer,
    unsigned buffer_length,
    uint64_t ip,
    uint16_t port);

const char*
Shannon_DefaultTcpPubUri(void);

const char*
Shannon_TcpPubUri(char* buffer, size_t buffer_length,
                  const char* address);

const char*
Shannon_TcpPubRawIPV4(char* buffer, size_t buffer_length,
                      Shannon_IPV4 ip);

const char*
Shannon_TcpPubRawIPV6(char* buffer, size_t buffer_length,
                      Shannon_IPV6 ip);

const char*
Shannon_TcpSubRawIPV4(char* buffer, size_t buffer_length,
                      Shannon_IPV4 ip);

const char*
Shannon_TcpSubRawIPV6(char* buffer, size_t buffer_length,
                      Shannon_IPV6 ip);

const char*
Shannon_DefaultTcpPubConnect(void);

const char*
Shannon_DefaultTcpSubUri(void);

const char*
Shannon_DefaultTcpReqUri(void);

const char*
Shannon_DefaultIpcRepUri(void);
/// }

/// {
/// These methods return the default broadcast.
void
Shannon_DefaultUdpIPv4(uint32_t* mask, uint16_t* port);

void
Shannon_DefaultUdpIPv6(uint32_t ip[4], uint16_t* port);
/// }

#ifdef __cplusplus
} // extern
#endif
#endif // SHANNON_CORE_NET_URI_H_
