#ifndef SHANNON_CORE_IDENTITY_H_
#define SHANNON_CORE_IDENTITY_H_

#include <stdint.h>

uint64_t
Shannon_GetIdentity(void);

#endif //SHANNON_CORE_IDENTITY_H_
