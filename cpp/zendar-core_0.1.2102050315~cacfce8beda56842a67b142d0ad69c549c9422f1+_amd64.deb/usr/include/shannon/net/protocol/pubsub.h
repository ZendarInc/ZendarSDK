#ifndef SHANNON_CORE_NET_PROTOCOL_PUBSUB_H_
#define SHANNON_CORE_NET_PROTOCOL_PUBSUB_H_

// ////////////////////////////////////////////////////////////////////////////
/// This file documents all of the structures and macros for creating a PUB/SUB
/// channel.
// ////////////////////////////////////////////////////////////////////////////

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

///
/// Macro for computing the offset of a member plus its size.  This should be
/// used in operations dealing with partial channel population, for example in
/// the Shannon_PubSubSocket_Subscribe function.
///
#define Shannon_ChannelLevel(_member_) \
  offsetof(Shannon_Channel, _member_) + sizeof(((Shannon_Channel*)0)->_member_)

//#pragma scalar_storage_order little-endian
typedef union __attribute__((aligned(8))) {
  /// This is a integral representation of the structure.
  uint64_t address;

  /// This is a helper which allows you do dereference it and easily
  /// cast to a `const char*`.
  ///
  ///   Shannon_Channel c;
  ///   const char* msg = &c.address_ptr;
  char address_ptr;

  struct {
    /// {
    /// Shannon_Class_Message message indicates that  this is an informational
    /// packet.
    #define Shannon_Class_Message   0x00

    /// Shannon_Class_Log indicates the published message is a log message.
    #define Shannon_Class_Log       0x01

    /// There is a special publish packet which relays all received UDP packets
    /// to a local publish channel, so other applications can receive the
    /// messages.
    #define Shannon_Class_Broadcast 0x02

    /// Certain sensors may need to broadcast outbound information describing
    /// the intrinsics of a new device.
    ///
    /// When a device connects, it may want to know the intrinsics.  So it may
    /// temporarily subscribe this channel and then unsubscribe when
    /// appropriate.
    #define Shannon_Class_Identification 0x03

    /// }
    uint8_t classification;

    union __attribute__((packed)) {
      struct __attribute__((packed)) {
        /// {
        /// There are two concepts of a system; a major system and a
        /// minor / system.
        ///
        /// Major systems map generally to sensor types, minor systems are
        /// message stream types on a sensor.  That is, a single sensor may
        /// be capable of providing multiple streams.
        #define Shannon_Message_System_RadarStrobe 1
        #define Shannon_Message_System_Tracklog    2
        uint8_t system_major;

        // Minor system for video SAR
        #define Shannon_Message_System_RadarImage  0
        // Minor system for tracker point clouds
        #define Shannon_Message_System_RadarPoints 1
        uint8_t system_minor;  // Should usually default to 0.
        /// }

        /// The channel indicates whatever that specific system wants
        /// it to mean.  Systems can feel free to make this always 0 and
        /// it will cause no problems.
        uint32_t channel;
      } message;

      struct __attribute__((packed)) {
        /// {
        /// Even though there are theoretically 256 different levels of
        /// logging, who needs that?
        ///
        /// We support 5 which cascade and include all below them.
        ///
        /// If you set `severity` to a value larger than 0x04, you are
        /// functionally generating a debug channel.  Debug channels are
        /// unique in that they allow arbitrary blobs of data to be
        /// transferred from the device as a log message (vs ASCII only
        /// logs).
        ///
        #define Shannon_Log_Severity_Fatal 0x00
        #define Shannon_Log_Severity_Error 0x01
        #define Shannon_Log_Severity_Warn  0x02
        #define Shannon_Log_Severity_Info  0x03
        #define Shannon_Log_Severity_Debug 0x04
        uint8_t  severity;
        /// #}

        /// Unused, use it how you see fit when opening debug channels or
        /// just leave it as all zero's.
        unsigned free_bits:24;
      } log;
    };
  } route;
} Shannon_Channel;
//#pragma scalar_storage_order default

#ifdef __cplusplus
} // extern
#endif



#endif // SHANNON_CORE_NET_PROTOCOL_PUBSUB_H_
