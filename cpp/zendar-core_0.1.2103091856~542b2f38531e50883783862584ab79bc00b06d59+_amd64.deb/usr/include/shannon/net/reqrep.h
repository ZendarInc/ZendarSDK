#ifndef SHANNON_CORE_NET_REQREP_H_
#define SHANNON_CORE_NET_REQREP_H_

#include <stdbool.h>
#include <string.h>

// -------------------------------------------------------------------------- //
// Request socket.
// -------------------------------------------------------------------------- //

#ifdef __cplusplus
extern "C" {
#endif

///
///
///
typedef void Shannon_ReqSocket;

///
///
///
Shannon_ReqSocket*
Shannon_ReqSocket_New(void);

///
///
///
void
Shannon_ReqSocket_Destroy(Shannon_ReqSocket* socket);

///
///
///
int
Shannon_ReqSocket_Connect(Shannon_ReqSocket* socket, const char* uri);

///
///
///
bool
Shannon_ReqSocket_SendReq(Shannon_ReqSocket* socket,
                          const void* data,
                          size_t size);

///
///
///
bool
Shannon_ReqSocket_RecvRes(Shannon_ReqSocket* socket,
                          void** data,
                          size_t* size);


// -------------------------------------------------------------------------- //
// Reply socket.
// -------------------------------------------------------------------------- //

///
///
///
typedef void Shannon_RepSocket;

///
///
///
Shannon_RepSocket*
Shannon_RepSocket_New(void);

///
///
///
void
Shannon_RepSocket_Destroy(Shannon_RepSocket* socket);

///
///
///
int
Shannon_RepSocket_Connect(Shannon_RepSocket* socket, const char* uri);

///
///
///
bool
Shannon_RepSocket_RecvReq(Shannon_RepSocket* socket,
                          void** data,
                          size_t* size);

///
///
///
bool
Shannon_RepSocket_SendRep(Shannon_RepSocket* socket,
                          const void* data,
                          size_t size);



#ifdef __cplusplus
} //
#endif


#endif // SHANNON_CORE_NET_REQREP_H_
