#ifndef SHANNON_CORE_NET_PROTOCOL_BROADCAST_H_
#define SHANNON_CORE_NET_PROTOCOL_BROADCAST_H_

// ////////////////////////////////////////////////////////////////////////////
/// This file documents all of the structures and macros for interpreting the
/// UDP broadcast messages.
///
/// The Shannon_Broadcast message is a UDP
// ////////////////////////////////////////////////////////////////////////////

#include <stdint.h>


#ifdef __cplusplus
extern "C" {
#endif

#pragma scalar_storage_order little-endian

// -------------------------------------------------------------------------- //

typedef struct __attribute__((packed)) {
  uint32_t address;
  uint32_t netmask;
} Shannon_Broadcast_Control_IPV4;

typedef struct __attribute__((packed)) {
  uint32_t address[4];
  uint32_t netmask[4];
} Shannon_Broadcast_Control_IPV6;

#define Shannon_Broadcast_Control_MaxRoutes 16

typedef struct __attribute__((packed)) {
  Shannon_Broadcast_Control_IPV4 identity;
  uint8_t                        routes_size;
  Shannon_Broadcast_Control_IPV4 routes[Shannon_Broadcast_Control_MaxRoutes];
} Shannon_Broadcast_Control_NetworkStaticIPV4;

typedef struct __attribute__((packed)) {
  Shannon_Broadcast_Control_IPV6 identity;
  uint8_t                        routes_size;
  Shannon_Broadcast_Control_IPV6 routes[Shannon_Broadcast_Control_MaxRoutes];
} Shannon_Broadcast_Control_NetworkStaticIPV6;

typedef struct __attribute__((packed)) {
  uint8_t                        routes_size;
  Shannon_Broadcast_Control_IPV4 routes[Shannon_Broadcast_Control_MaxRoutes];
} Shannon_Broadcast_Control_NetworkDHCPIPV4;

typedef struct __attribute__((packed)) {
  uint8_t                        routes_size;
  Shannon_Broadcast_Control_IPV6 routes[Shannon_Broadcast_Control_MaxRoutes];
} Shannon_Broadcast_Control_NetworkDHCPIPV6;

typedef struct __attribute__((packed)) {
  uint8_t                        routes_size;
  Shannon_Broadcast_Control_IPV4 routes[Shannon_Broadcast_Control_MaxRoutes];
} Shannon_Broadcast_Control_NetworkLinkLocalIPV4;

typedef struct __attribute__((packed)) {
  Shannon_Broadcast_Control_IPV6 routes[Shannon_Broadcast_Control_MaxRoutes];
} Shannon_Broadcast_Control_NetworkLinkLocalIPV6;

typedef enum {
  NETWORK_STATIC_IPV4    = 1,
  NETWORK_STATIC_IPV6    = 2,
  NETWORK_DHCP_IPV4      = 3,
  NETWORK_DHCP_IPV6      = 4,
  NETWORK_LINKLOCAL_IPV4 = 5,
  NETWORK_LINKLOCAL_IPV6 = 6,
} Shannon_Broadcast_ControlType;

typedef struct __attribute__((packed)) {
  /// I have a suspicion an authorization schema may eventually be needed for
  /// ensuring rogue programs do not attempt to control the device
  /// 'accidentally'.  At that point, encryption will be needed.
  ///
  /// 512 bytes should be sufficient to store signatures and metadata for the
  /// signing key.  Also, there's not a ton of harm... it's only 1/3rd of the
  /// MTU with every control message being small.
  uint8_t signed_header[512];
  uint8_t persist;
  uint8_t type;
  union {
    Shannon_Broadcast_Control_NetworkStaticIPV4    static_ipv4;
    Shannon_Broadcast_Control_NetworkStaticIPV6    static_ipv6;
    Shannon_Broadcast_Control_NetworkDHCPIPV4      dhcp_ipv4;
    Shannon_Broadcast_Control_NetworkDHCPIPV6      dhcp_ipv6;
    Shannon_Broadcast_Control_NetworkLinkLocalIPV4 linklocal_ipv4;
    Shannon_Broadcast_Control_NetworkLinkLocalIPV6 linklocal_ipv6;
  };
} Shannon_Broadcast_Control;

// -------------------------------------------------------------------------- //
/// {
/// This block of structures refer to the 1Hz UDP informational broadcast

typedef struct __attribute__((packed)) {
  uint32_t address;
  uint32_t netmask;
} Shannon_IPV4;

typedef struct __attribute__((packed)) {
  uint32_t address[4];
  uint32_t netmask[4];
} Shannon_IPV6;

typedef struct __attribute__((packed)) {
  #define Shannon_IP_NONE 0x00
  #define Shannon_IP_IPV4 0x04
  #define Shannon_IP_IPV6 0x10
  uint8_t      type; // This is a mask of which types are enabled.
  uint16_t     mbps; // Megabits per second available on channel.
  uint8_t      flag; // Unused
  Shannon_IPV4 ipv4;
  Shannon_IPV6 ipv6;
} Shannon_IP;


typedef struct __attribute__((packed)) {
  /// This is a unique identity of this sender.  Every device will be unique.
  uint64_t unique_identity;

  /// The units of this are in 0.1ms. So...
  ///   `double t = timestamp * 1e-4`
  ///
  /// This field is used to help synchronize timestamps.
  uint64_t timestamp;

  /// This field helps people detect dropped packets.
  uint64_t packet_sequence_no;

  /// This is a 64 bit number which olds various state flags.
  struct {
    /// {
    /// This 8bit block is dedicated to zensor peripheral types.
    unsigned is_zensor_processing_unit:1;
    unsigned is_zensor_host_controller:1;
    unsigned is_zensor_debugging_probe:1;
    unsigned unused0                  :5;
    /// }

    /// {
    /// This 16bit block assumes that `is_zensor_processing_unit` is true.
    unsigned radars_attached        :3;
    unsigned has_vn200              :1;
    unsigned is_currently_processing:1;
    unsigned unused1                :11;
    /// }

    /// {
    /// This 8bit block assumes that `is_zensor_host_controller` is true.
    unsigned unused2:16;
    /// }

    /// This 8bit block assumes that `is_zensor_debugging_probe` is true.
    unsigned unused3:8;
  } capabilities;

  // Only two networking devices are permitted to be used on the device.
  #define Shannon_MAXIMUM_IP_COUNT 2
  Shannon_IP ips[Shannon_MAXIMUM_IP_COUNT];
} Shannon_Identity;

#define Shannon_Broadcast_VectorLength 16

typedef struct __attribute__((packed)) {
  /// The projected identity of this neighbor.
  Shannon_Identity identity;

  /// Estimated number of packets this neighbor should have sent.
  uint32_t estimated_packet_sent;

  /// Estimated number of packets I am certain I have lost from this neighbor.
  uint32_t estimated_packet_lost;
} Shannon_Broadcast_Neighbor;

typedef struct __attribute__((packed)) {
  /// Holds the identity of this sender.
  Shannon_Identity identity;

  /// {
  /// These are the neighbors currently observed.
  #define Shannon_Broadcast_Information_MaxNeighbors 8
  Shannon_Broadcast_Neighbor neighbor[
       Shannon_Broadcast_Information_MaxNeighbors];
  /// }
} Shannon_Broadcast_Information;
/// }

// -------------------------------------------------------------------------- //
/// {
#define Shannon_ZensorHeader_V0 0x333c5241444e455a
#define Shannon_ZensorHeader_V1

typedef enum {
  Shannon_Broadcast_Type_Ignore        = 0x0,
  Shannon_Broadcast_Type_Informational = 0x1,
  Shannon_Broadcast_Type_Control       = 0x2
} Shannon_Broadcast_Type;

typedef struct __attribute__((packed)) {
  // {
  uint64_t head; // Shannon_ZensorHeader
  uint16_t size; // Size in bytes
  uint16_t hash; // Probably will be a CRC16.
  // }

  // {
  uint8_t  type; // Shannon_Broadcast_Type_{...}
  uint8_t  flag; // currently unused message flags.
  // }

  union {
    Shannon_Broadcast_Information info;
    Shannon_Broadcast_Control     ctrl;
  } mesg;
} Shannon_Broadcast;

#ifdef __cplusplus
} // extern
#endif


#endif // SHANNON_CORE_NET_PROTOCOL_BROADCAST_H_
