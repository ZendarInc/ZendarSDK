#ifndef SHANNON_CORE_LOG_H_
#define SHANNON_CORE_LOG_H_

#include <stdio.h>


#ifndef NDEBUG
#define LogDebug(...)                   \
    do {                                \
      fprintf(stderr, "DEBUG:" __VA_ARGS__); \
    } while (0)

#define LogInfo(...)                    \
    do {                                \
      fprintf(stderr, "INFO:" __VA_ARGS__); \
    } while (0)
#else
#define LogDebug(...) do {} while (0)
#define LogInfo(...)  do {} while (0)
#endif

#define LogWarn(...)                    \
    do {                                \
      fprintf(stderr, "WARNING:" __VA_ARGS__); \
    } while (0)

#define LogFatal(...)                   \
    do {                                \
      fprintf(stderr, "FATAL:" __VA_ARGS__); \
    } while (0)

#endif // SHANNON_CORE_LOG_H_
