#ifndef ZENDAR_API_H_
#define ZENDAR_API_H_

#include <atomic>
#include <string>
#include <thread>
#include <unordered_map>

#include "data.pb.h"
#include "reqrep.pb.h"

// Opaque handle for a pubsub socket.
typedef void PubSubSocket;
// Opaque handle for a reqrep socket.
typedef void ReqSocket;
// Opaque handles for the internal queues.
typedef void ImageQueue;
typedef void TrackerQueue;
typedef void LogQueue;
typedef void TracklogQueue;

namespace zendar {
enum ZendarError {
  ZENDAR_API_OK = 0,
  ZENDAR_API_CONNECT_FAILURE = 1,
  ZENDAR_API_SUBSCRIBE_FAILURE = 2,
  ZENDAR_API_UNSUBSCRIBE_FAILURE = 3,
  ZENDAR_API_TIMEOUT = 4,
  ZENDAR_API_QUEUE_ERROR = 5,
  ZENDAR_API_NOT_SUBSCRIBED = 6,
  ZENDAR_API_PROTOBUF_ERROR = 7,
  ZENDAR_API_REQUEST_FAILURE = 8,
  ZENDAR_API_OTHER_ERROR = 100
};

// Forward declaration of DataType enum
enum DataType: int;

class ZendarReceiver {
public:
  explicit ZendarReceiver(const std::string uri);
  ~ZendarReceiver();

  ZendarError Connect();
  void Disconnect();
  // Subscribe to the various data products.
  ZendarError SubscribeImages(std::size_t queue_size = 100);
  ZendarError SubscribeTracker(std::size_t queue_size = 100);
  ZendarError SubscribeTracklog(std::size_t queue_size = 100);
  ZendarError SubscribeLogs(std::size_t queue_size = 500);

  ZendarError UnsubscribeImages();
  ZendarError UnsubscribeTracker();
  ZendarError UnsubscribeTracklog();
  ZendarError UnsubscribeLogs();

  // These return ZENDAR_API_OK if the queue was popped successfully
  ZendarError NextImage(zen_proto::data::Image& proto, int timeout = -1);
  ZendarError NextTracker(zen::tracker::message::TrackerState& proto,
                          int timeout = -1);
  ZendarError NextTracklog(zen_proto::data::Position& proto,
                           int timeout = -1);
  ZendarError NextLogMessage(zen_proto::data::LogRecord& proto,
                             int timeout = -1);

  // Commands for controlling the ZPU
  ZendarError Start(std::string name);
  ZendarError Stop();
  ZendarError Status(zen_proto::control::Response& rep);
  ZendarError ListConfigurations(zen_proto::control::Response& rep);

private:
  ZendarError InitSocket(PubSubSocket* socket);
  ZendarError SendControlMessage(const zen_proto::control::Request& req,
                                 zen_proto::control::Response& rep);
  void SpinImages();
  void SpinTracker();
  void SpinTracklog();
  void SpinLogs();

  std::string uri;
  std::unordered_map<DataType, PubSubSocket*> sockets;
  std::unordered_map<DataType, std::thread> threads;
  std::unordered_map<DataType, std::atomic_bool> active_threads;
  ReqSocket* req_socket;

  ImageQueue* images;
  TrackerQueue* tracker_states;
  TracklogQueue* tracklog_positions;
  LogQueue* logs;
};

}  // namespace zen
#endif  // ZENDAR_API_H_
