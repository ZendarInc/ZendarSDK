#ifndef ZENDAR_API_H_
#define ZENDAR_API_H_

#include <atomic>
#include <string>
#include <thread>
#include <unordered_map>
#include "data.pb.h"

// Opaque handle for a pubsub socket.
typedef void PubSubSocket;

// Opaque handles for the internal queues.
typedef void ImageQueue;
typedef void TrackerQueue;
typedef void LogQueue;
typedef void TracklogQueue;

namespace zendar {
enum ZendarError {
  ZENDAR_API_OK = 0,
  ZENDAR_API_SUBSCRIBE_FAILURE = 1,
  ZENDAR_API_UNSUBSCRIBE_FAILURE = 2,
  ZENDAR_API_TIMEOUT = 3,
  ZENDAR_API_QUEUE_ERROR = 4,
  ZENDAR_API_NOT_SUBSCRIBED = 5,
  ZENDAR_API_PROTOBUF_ERROR = 6,
  ZENDAR_API_OTHER_ERROR = 7
};

// Forward declaration of DataType enum
enum DataType: int;

class ZendarReceiver {
public:
  ZendarReceiver(std::string uri);
  ~ZendarReceiver();
  // Subscribe to the various data products.
  ZendarError SubscribeImages(std::size_t queue_size = 100);
  ZendarError SubscribeTracker(std::size_t queue_size = 100);
  ZendarError SubscribeTracklog(std::size_t queue_size = 100);
  ZendarError SubscribeLogs(std::size_t queue_size = 500);

  ZendarError UnsubscribeImages();
  ZendarError UnsubscribeTracker();
  ZendarError UnsubscribeTracklog();
  ZendarError UnsubscribeLogs();

  // These return ZENDAR_API_OK if the queue was popped successfully
  ZendarError NextImage(zen_proto::data::Image& proto, int timeout = -1);
  ZendarError NextTracker(zen::tracker::message::TrackerState& proto,
                          int timeout = -1);
  ZendarError NextTracklog(zen_proto::data::Position& proto,
                           int timeout = -1);
  ZendarError NextLogMessage(zen_proto::data::LogRecord& proto,
                             int timeout = -1);

private:
  ZendarError InitSocket(PubSubSocket* socket);
  void SpinImages();
  void SpinTracker();
  void SpinTracklog();
  void SpinLogs();

  std::string uri;
  std::unordered_map<DataType, PubSubSocket*> sockets;
  std::unordered_map<DataType, std::thread> threads;
  std::unordered_map<DataType, std::atomic_bool> active_threads;

  ImageQueue* images;
  TrackerQueue* tracker_states;
  TracklogQueue* tracklog_positions;
  LogQueue* logs;
};

}  // namespace zen
#endif  // ZENDAR_API_H_
